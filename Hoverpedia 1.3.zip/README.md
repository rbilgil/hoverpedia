Hoverpedia
==========

Browsing Wikipedia should be seamless and painless, but the number of tabs you end up opening is ridiculous! 
With this Chrome extension, hover over any Wikipedia link to read the first few sentences instantly.

###Changelog
**v1.0 Initial release:**
    - Supports hovering over any link within Wikipedia to see preview of the link

**v1.1:**
    - Improved visuals
    - Many under-the-hood changes to improve the consistency of how the popup displays
    - Displays the popup from any site that links to Wikipedia!
    - Updated to have logo in extension settings

###License
Do whatever you want, use it however you like!




